import BASE from './_base.page'
import {CHECKOUT} from '../elements/sauce.elements'
import {NAVBAR} from '../elements/sauce.elements'

export default class SauceCheckout extends Base{

}